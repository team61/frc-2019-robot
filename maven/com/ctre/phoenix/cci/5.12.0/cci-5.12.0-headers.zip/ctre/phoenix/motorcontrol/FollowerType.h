#pragma once

namespace ctre {
namespace phoenix {
namespace motorcontrol {

enum FollowerType {
	FollowerType_PercentOutput = 0,
	FollowerType_AuxOutput1,
};

} // namespace motorcontrol
} // namespace phoenix
} // namespace ctre
