#pragma once

namespace ctre{
namespace phoenix{
    enum AutocacheState{
        DISABLED = 0,
        ENABLED = 1,
    };
}
}